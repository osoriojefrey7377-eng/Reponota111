package edu.eam.ingesoft.logica.cotizador;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Clase de pruebas unitarias para CotizadorSeguro.
 * Verifica el correcto funcionamiento de todos los métodos de cálculo y validación.
 */
public class CotizadorSeguroTest {

    private CotizadorSeguro cotizador;

    @BeforeEach
    public void setUp() {
        // Inicializar con datos de prueba estándar
        cotizador = new CotizadorSeguro(
            "Toyota", "Corolla", 2020, 25000,
            "Juan Pérez", 35, "Masculino", 10,
            "Intermedia", true, false, 10
        );
    }

    @Test
    @DisplayName("Test 1: Calcular prima base con cobertura básica")
    public void testCalcularPrimaBaseBasica() {
        CotizadorSeguro cotizadorBasico = new CotizadorSeguro(
            "Honda", "Civic", 2019, 20000,
            "Ana López", 28, "Femenino", 5,
            "Básica", false, false, 0
        );
        double primaBase = cotizadorBasico.calcularPrimaBase();
        assertTrue(primaBase >= 0, "La prima base debe ser mayor o igual a 0");
        assertEquals(600.0, primaBase, 0.01, "Prima base para cobertura básica de $20,000 debe ser $600");
    }

    @Test
    @DisplayName("Test 2: Calcular prima base con cobertura intermedia")
    public void testCalcularPrimaBaseIntermedia() {
        double primaBase = cotizador.calcularPrimaBase();
        assertTrue(primaBase >= 0, "La prima base debe ser mayor o igual a 0");
        assertEquals(1000.0, primaBase, 0.01, "Prima base para cobertura intermedia de $25,000 debe ser $1,000");
    }

    @Test
    @DisplayName("Test 3: Calcular prima base con cobertura premium")
    public void testCalcularPrimaBasePremium() {
        CotizadorSeguro cotizadorPremium = new CotizadorSeguro(
            "BMW", "X5", 2021, 50000,
            "Carlos Ruiz", 45, "Masculino", 20,
            "Premium", true, true, 5
        );
        double primaBase = cotizadorPremium.calcularPrimaBase();
        assertTrue(primaBase >= 0, "La prima base debe ser mayor o igual a 0");
        assertEquals(2500.0, primaBase, 0.01, "Prima base para cobertura premium de $50,000 debe ser $2,500");
    }

    @Test
    @DisplayName("Test 4: Factor de edad para conductor joven (menor de 25)")
    public void testFactorEdadConductorJoven() {
        CotizadorSeguro cotizadorJoven = new CotizadorSeguro(
            "Nissan", "Sentra", 2020, 18000,
            "Pedro García", 22, "Masculino", 2,
            "Básica", false, false, 15
        );
        double factorEdad = cotizadorJoven.calcularFactorEdad();
        assertEquals(1.5, factorEdad, 0.01, "El factor de edad para menores de 25 debe ser 1.5");
    }

    @Test
    @DisplayName("Test 5: Factor de edad para conductor adulto (25-65 años)")
    public void testFactorEdadConductorAdulto() {
        double factorEdad = cotizador.calcularFactorEdad();
        assertEquals(1.0, factorEdad, 0.01, "El factor de edad para conductores entre 25-65 años debe ser 1.0");
    }

    @Test
    @DisplayName("Test 6: Factor de edad para conductor mayor (más de 65)")
    public void testFactorEdadConductorMayor() {
        CotizadorSeguro cotizadorMayor = new CotizadorSeguro(
            "Ford", "Focus", 2018, 15000,
            "Roberto Sánchez", 70, "Masculino", 40,
            "Intermedia", true, false, 20
        );
        double factorEdad = cotizadorMayor.calcularFactorEdad();
        assertEquals(1.3, factorEdad, 0.01, "El factor de edad para mayores de 65 debe ser 1.3");
    }

    @Test
    @DisplayName("Test 7: Factor de experiencia para conductor novato")
    public void testFactorExperienciaNovato() {
        CotizadorSeguro cotizadorNovato = new CotizadorSeguro(
            "Mazda", "3", 2021, 22000,
            "Laura Martínez", 25, "Femenino", 1,
            "Básica", false, false, 10
        );
        double factorExp = cotizadorNovato.calcularFactorExperiencia();
        assertEquals(1.3, factorExp, 0.01, "El factor de experiencia para menos de 2 años debe ser 1.3");
    }

    @Test
    @DisplayName("Test 8: Factor de experiencia para conductor experimentado")
    public void testFactorExperienciaExperimentado() {
        double factorExp = cotizador.calcularFactorExperiencia();
        assertEquals(0.9, factorExp, 0.01, "El factor de experiencia para más de 10 años debe ser 0.9");
    }

    @Test
    @DisplayName("Test 9: Factor de antigüedad del vehículo nuevo")
    public void testFactorAntiguedadVehiculoNuevo() {
        CotizadorSeguro cotizadorNuevo = new CotizadorSeguro(
            "Tesla", "Model 3", 2024, 40000,
            "María Rodríguez", 30, "Femenino", 5,
            "Premium", true, true, 5
        );
        double factorAntiguedad = cotizadorNuevo.calcularFactorAntiguedad();
        assertEquals(1.0, factorAntiguedad, 0.01, "El factor de antigüedad para vehículos de menos de 3 años debe ser 1.0");
    }

    @Test
    @DisplayName("Test 10: Descuento por deducible alto (20%)")
    public void testDescuentoDeducibleAlto() {
        CotizadorSeguro cotizadorDeducible = new CotizadorSeguro(
            "Hyundai", "Elantra", 2020, 20000,
            "José López", 40, "Masculino", 15,
            "Intermedia", false, false, 20
        );
        double descuento = cotizadorDeducible.calcularDescuentoDeducible();
        assertEquals(0.15, descuento, 0.01, "El descuento por deducible del 20% debe ser 0.15");
    }

    @Test
    @DisplayName("Test 11: Costos adicionales con todos los servicios")
    public void testCostosAdicionalesCompletos() {
        CotizadorSeguro cotizadorCompleto = new CotizadorSeguro(
            "Volkswagen", "Jetta", 2021, 28000,
            "Patricia Gómez", 32, "Femenino", 8,
            "Premium", true, true, 10
        );
        double costosAdicionales = cotizadorCompleto.calcularCostosAdicionales();
        assertEquals(1700.0, costosAdicionales, 0.01, "Los costos adicionales con asistencia y reemplazo deben ser $1,700");
    }

    @Test
    @DisplayName("Test 12: Verificar elegibilidad - conductor menor de edad")
    public void testElegibilidadMenorEdad() {
        CotizadorSeguro cotizadorMenor = new CotizadorSeguro(
            "Kia", "Rio", 2020, 15000,
            "Diego Ruiz", 17, "Masculino", 0,
            "Básica", false, false, 0
        );
        assertFalse(cotizadorMenor.esElegible(), "Un conductor menor de 18 años no debe ser elegible");
    }

    @Test
    @DisplayName("Test 13: Verificar elegibilidad - conductor elegible")
    public void testElegibilidadConductorValido() {
        assertTrue(cotizador.esElegible(), "Un conductor de 35 años debe ser elegible");
    }

    @Test
    @DisplayName("Test 14: Calificar para descuento de buen conductor")
    public void testCalificaDescuentoBuenConductor() {
        CotizadorSeguro buenConductor = new CotizadorSeguro(
            "Subaru", "Impreza", 2019, 23000,
            "Andrea Silva", 40, "Femenino", 15,
            "Intermedia", false, false, 10
        );
        assertTrue(buenConductor.calificaDescuentoBuenConductor(),
            "Un conductor de 40 años con 15 años de experiencia debe calificar para descuento");
    }

    @Test
    @DisplayName("Test 15: No califica para descuento de buen conductor")
    public void testNoCalificaDescuentoBuenConductor() {
        CotizadorSeguro malConductor = new CotizadorSeguro(
            "Chevrolet", "Aveo", 2020, 16000,
            "Luis Mendoza", 23, "Masculino", 1,
            "Básica", false, false, 0
        );
        assertFalse(malConductor.calificaDescuentoBuenConductor(),
            "Un conductor de 23 años con 1 año de experiencia no debe calificar para descuento");
    }

    @Test
    @DisplayName("Test 16: Calcular monto máximo de cobertura básica")
    public void testMontoMaximoCoberturaBasica() {
        CotizadorSeguro coberturaBasica = new CotizadorSeguro(
            "Peugeot", "208", 2020, 18000,
            "Fernando Castro", 30, "Masculino", 5,
            "Básica", false, false, 10
        );
        double montoMaximo = coberturaBasica.calcularMontoMaximoCobertura();
        assertEquals(18000.0, montoMaximo, 0.01, "El monto máximo para cobertura básica debe ser el valor del vehículo");
    }

    @Test
    @DisplayName("Test 17: Requiere inspección para vehículo antiguo")
    public void testRequiereInspeccionVehiculoAntiguo() {
        CotizadorSeguro vehiculoAntiguo = new CotizadorSeguro(
            "Renault", "Logan", 2010, 8000,
            "Miguel Torres", 45, "Masculino", 20,
            "Básica", false, false, 15
        );
        assertTrue(vehiculoAntiguo.requiereInspeccion(),
            "Un vehículo del 2010 debe requerir inspección");
    }

    @Test
    @DisplayName("Test 18: Validar datos correctos")
    public void testValidarDatosCorrectos() {
        assertTrue(cotizador.validarDatos(), "Los datos del cotizador estándar deben ser válidos");
    }

    @Test
    @DisplayName("Test 19: Calcular prima mensual")
    public void testCalcularPrimaMensual() {
        double primaMensual = cotizador.calcularPrimaMensual();
        double primaAnual = cotizador.calcularPrimaTotal();
        assertEquals(primaAnual / 12, primaMensual, 0.01,
            "La prima mensual debe ser la prima anual dividida entre 12");
    }

    @Test
    @DisplayName("Test 20: Getters y Setters - Marca del vehículo")
    public void testGetSetMarcaVehiculo() {
        cotizador.setMarcaVehiculo("Mercedes");
        assertEquals("Mercedes", cotizador.getMarcaVehiculo(),
            "El setter y getter de marca deben funcionar correctamente");
    }

    @Test
    @DisplayName("Test 21: Getters y Setters - Edad del conductor")
    public void testGetSetEdadConductor() {
        cotizador.setEdadConductor(45);
        assertEquals(45, cotizador.getEdadConductor(),
            "El setter y getter de edad deben funcionar correctamente");
    }

    @Test
    @DisplayName("Test 22: Getters y Setters - Tipo de cobertura")
    public void testGetSetTipoCobertura() {
        cotizador.setTipoCobertura("Premium");
        assertEquals("Premium", cotizador.getTipoCobertura(),
            "El setter y getter de tipo de cobertura deben funcionar correctamente");
    }

    @Test
    @DisplayName("Test 23: Generar resumen de cotización no vacío")
    public void testGenerarResumenCotizacion() {
        String resumen = cotizador.generarResumenCotizacion();
        assertNotNull(resumen, "El resumen no debe ser null");
        assertFalse(resumen.isEmpty(), "El resumen no debe estar vacío");
    }

    @Test
    @DisplayName("Test 24: Prima total con todos los factores")
    public void testCalcularPrimaTotalCompleta() {
        double primaTotal = cotizador.calcularPrimaTotal();
        assertTrue(primaTotal >= 0, "La prima total debe ser mayor o igual a 0");
    }

    @Test
    @DisplayName("Test 25: Validar datos con valor negativo de vehículo")
    public void testValidarDatosValorNegativo() {
        CotizadorSeguro cotizadorInvalido = new CotizadorSeguro(
            "Ford", "Fiesta", 2020, -5000,
            "Juan Pérez", 30, "Masculino", 5,
            "Básica", false, false, 0
        );
        assertFalse(cotizadorInvalido.validarDatos(),
            "Un vehículo con valor negativo no debe pasar la validación");
    }
}