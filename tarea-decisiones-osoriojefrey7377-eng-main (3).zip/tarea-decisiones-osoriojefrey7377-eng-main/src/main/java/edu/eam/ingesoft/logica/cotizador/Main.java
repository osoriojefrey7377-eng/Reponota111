package edu.eam.ingesoft.logica.cotizador;

import javax.swing.*;

/**
 * Clase principal que inicia la aplicación de cotización de seguros.
 */
public class Main {

    /**
     * Método principal que ejecuta la aplicación.
     *
     * @param args Argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        // Configurar el look and feel del sistema
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Si no se puede establecer el look and feel del sistema, usar el default
            e.printStackTrace();
        }

        // Ejecutar la interfaz gráfica en el Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            CotizadorSeguroGUI ventana = new CotizadorSeguroGUI();
            ventana.setVisible(true);
        });
    }
}