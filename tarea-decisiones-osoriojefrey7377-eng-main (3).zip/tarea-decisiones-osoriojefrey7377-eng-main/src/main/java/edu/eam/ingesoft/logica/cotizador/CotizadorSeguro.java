package edu.eam.ingesoft.logica.cotizador;

import java.time.Year;

/**
 * Clase que representa un cotizador de seguros de automóviles.
 * Calcula el costo del seguro basado en diferentes factores como el valor del vehículo,
 * edad del conductor, tipo de cobertura y condiciones especiales.
 */
public class CotizadorSeguro {


    private String marcaVehiculo;
    private String modeloVehiculo;
    private int anioVehiculo;
    private double valorVehiculo;


    private String nombreConductor;
    private int edadConductor;
    private String generoConductor;
    private int aniosExperiencia;


    private String tipoCobertura;
    private boolean incluyeAsistenciaVial;
    private boolean incluyeVehiculoReemplazo;
    private int deduciblePorcentaje;

    // Constructor
    public CotizadorSeguro(String marcaVehiculo, String modeloVehiculo, int anioVehiculo,
                           double valorVehiculo, String nombreConductor, int edadConductor,
                           String generoConductor, int aniosExperiencia, String tipoCobertura,
                           boolean incluyeAsistenciaVial, boolean incluyeVehiculoReemplazo,
                           int deduciblePorcentaje) {
        this.marcaVehiculo = marcaVehiculo;
        this.modeloVehiculo = modeloVehiculo;
        this.anioVehiculo = anioVehiculo;
        this.valorVehiculo = valorVehiculo;
        this.nombreConductor = nombreConductor;
        this.edadConductor = edadConductor;
        this.generoConductor = generoConductor;
        this.aniosExperiencia = aniosExperiencia;
        this.tipoCobertura = tipoCobertura;
        this.incluyeAsistenciaVial = incluyeAsistenciaVial;
        this.incluyeVehiculoReemplazo = incluyeVehiculoReemplazo;
        this.deduciblePorcentaje = deduciblePorcentaje;
    }

    /**
     * Calcula la prima base según el tipo de cobertura
     */
    public double calcularPrimaBase() {
        double prima = 0;

        if (tipoCobertura.equalsIgnoreCase("Básica")) {
            prima = valorVehiculo * 0.03;
        } else if (tipoCobertura.equalsIgnoreCase("Intermedia")) {
            prima = valorVehiculo * 0.04;
        } else if (tipoCobertura.equalsIgnoreCase("Premium")) {
            prima = valorVehiculo * 0.05;
        }

        return prima;
    }

    /**
     * Calcula el factor de edad
     */
    public double calcularFactorEdad() {
        if (edadConductor < 25) {
            return 1.5;
        } else if (edadConductor > 65) {
            return 1.3;
        } else {
            return 1.0;
        }
    }

    /**
     * Calcula el factor por experiencia del conductor
     */
    public double calcularFactorExperiencia() {
        if (aniosExperiencia < 2) {
            return 1.3;
        } else if (aniosExperiencia < 5) {
            return 1.1;
        } else if (aniosExperiencia <= 10) {
            return 1.0;
        } else {
            return 0.9;
        }
    }

    /**
     * Calcula el factor por antigüedad del vehículo
     */
    public double calcularFactorAntiguedad() {
        int anioActual = Year.now().getValue();
        int antiguedad = anioActual - anioVehiculo;

        if (antiguedad <= 3) {
            return 1.0;
        } else if (antiguedad <= 7) {
            return 1.1;
        } else if (antiguedad <= 10) {
            return 1.2;
        } else {
            return 1.3;
        }
    }

    /**
     * Calcula el descuento por deducible
     */
    public double calcularDescuentoDeducible() {
        switch (deduciblePorcentaje) {
            case 5:
                return 0.03;
            case 10:
                return 0.07;
            case 15:
                return 0.11;
            case 20:
                return 0.15;
            default:
                return 0.0;
        }
    }

    /**
     * Calcula los costos adicionales de servicios
     */
    public double calcularCostosAdicionales() {
        double costo = 0;
        if (incluyeAsistenciaVial) {
            costo += 500;
        }
        if (incluyeVehiculoReemplazo) {
            costo += 1200;
        }
        return costo;
    }

    /**
     * Calcula la prima total anual del seguro
     */
    public double calcularPrimaTotal() {
        double primaBase = calcularPrimaBase();
        double factorEdad = calcularFactorEdad();
        double factorExp = calcularFactorExperiencia();
        double factorAntiguedad = calcularFactorAntiguedad();
        double descuento = calcularDescuentoDeducible();
        double costosExtras = calcularCostosAdicionales();

        double prima = (primaBase * factorEdad * factorExp * factorAntiguedad) * (1 - descuento);
        prima += costosExtras;

        return prima;
    }

    /**
     * Calcula la prima mensual
     */
    public double calcularPrimaMensual() {
        return calcularPrimaTotal() / 12;
    }

    /**
     * Determina si el conductor es elegible
     */
    public boolean esElegible() {
        return edadConductor >= 18 && valorVehiculo > 0;
    }

    /**
     * Verifica si el conductor califica para descuento por buen conductor
     */
    public boolean calificaDescuentoBuenConductor() {
        return edadConductor >= 30 && edadConductor <= 60 && aniosExperiencia > 5;
    }

    /**
     * Calcula el monto máximo de cobertura
     */
    public double calcularMontoMaximoCobertura() {
        if (tipoCobertura.equalsIgnoreCase("Básica")) {
            return valorVehiculo;
        } else if (tipoCobertura.equalsIgnoreCase("Intermedia")) {
            return valorVehiculo * 1.5;
        } else if (tipoCobertura.equalsIgnoreCase("Premium")) {
            return valorVehiculo * 2;
        } else {
            return 0;
        }
    }

    /**
     * Determina si el vehículo requiere inspección previa
     */
    public boolean requiereInspeccion() {
        int anioActual = Year.now().getValue();
        int antiguedad = anioActual - anioVehiculo;

        return antiguedad > 10 || valorVehiculo > 50000;
    }

    /**
     * Genera un resumen de la cotización
     */
    public String generarResumenCotizacion() {
        double primaBase = calcularPrimaBase();
        double primaTotal = calcularPrimaTotal();
        double primaMensual = calcularPrimaMensual();

        String resumen = "Cotización de Seguro - " + tipoCobertura + "\n";
        resumen += "Prima Base: $" + String.format("%.2f", primaBase) + "\n";
        resumen += "Prima Total Anual: $" + String.format("%.2f", primaTotal) + "\n";
        resumen += "Prima Mensual: $" + String.format("%.2f", primaMensual) + "\n";

        if (incluyeAsistenciaVial) {
            resumen += "- Incluye Asistencia Vial\n";
        }
        if (incluyeVehiculoReemplazo) {
            resumen += "- Incluye Vehículo de Reemplazo\n";
        }

        return resumen;
    }

    /**
     * Valida que todos los datos sean correctos
     */
    public boolean validarDatos() {
        boolean coberturaValida = tipoCobertura.equalsIgnoreCase("Básica") ||
                tipoCobertura.equalsIgnoreCase("Intermedia") ||
                tipoCobertura.equalsIgnoreCase("Premium");

        if (valorVehiculo <= 0) return false;
        if (edadConductor < 18) return false;
        if (aniosExperiencia < 0) return false;
        if (aniosExperiencia > (edadConductor - 16)) return false;
        if (!coberturaValida) return false;

        return true;
    }

    // ---------------- Getters y Setters ----------------

    public String getMarcaVehiculo() { return marcaVehiculo; }
    public void setMarcaVehiculo(String marcaVehiculo) { this.marcaVehiculo = marcaVehiculo; }

    public String getModeloVehiculo() { return modeloVehiculo; }
    public void setModeloVehiculo(String modeloVehiculo) { this.modeloVehiculo = modeloVehiculo; }

    public int getAnioVehiculo() { return anioVehiculo; }
    public void setAnioVehiculo(int anioVehiculo) { this.anioVehiculo = anioVehiculo; }

    public double getValorVehiculo() { return valorVehiculo; }
    public void setValorVehiculo(double valorVehiculo) { this.valorVehiculo = valorVehiculo; }

    public String getNombreConductor() { return nombreConductor; }
    public void setNombreConductor(String nombreConductor) { this.nombreConductor = nombreConductor; }

    public int getEdadConductor() { return edadConductor; }
    public void setEdadConductor(int edadConductor) { this.edadConductor = edadConductor; }

    public String getGeneroConductor() { return generoConductor; }
    public void setGeneroConductor(String generoConductor) { this.generoConductor = generoConductor; }

    public int getAniosExperiencia() { return aniosExperiencia; }
    public void setAniosExperiencia(int aniosExperiencia) { this.aniosExperiencia = aniosExperiencia; }

    public String getTipoCobertura() { return tipoCobertura; }
    public void setTipoCobertura(String tipoCobertura) { this.tipoCobertura = tipoCobertura; }

    public boolean isIncluyeAsistenciaVial() { return incluyeAsistenciaVial; }
    public void setIncluyeAsistenciaVial(boolean incluyeAsistenciaVial) { this.incluyeAsistenciaVial = incluyeAsistenciaVial; }

    public boolean isIncluyeVehiculoReemplazo() { return incluyeVehiculoReemplazo; }
    public void setIncluyeVehiculoReemplazo(boolean incluyeVehiculoReemplazo) { this.incluyeVehiculoReemplazo = incluyeVehiculoReemplazo; }

    public int getDeduciblePorcentaje() { return deduciblePorcentaje; }
    public void setDeduciblePorcentaje(int deduciblePorcentaje) { this.deduciblePorcentaje = deduciblePorcentaje; }
}