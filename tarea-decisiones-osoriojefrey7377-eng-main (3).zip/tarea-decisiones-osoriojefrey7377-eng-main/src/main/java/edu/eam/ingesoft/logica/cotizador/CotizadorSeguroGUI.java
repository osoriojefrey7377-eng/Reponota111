package edu.eam.ingesoft.logica.cotizador;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.Calendar;

/**
 * Interfaz gráfica para el sistema de cotización de seguros de automóviles.
 * Permite ingresar datos del vehículo, conductor y opciones de seguro para calcular la prima.
 */
public class CotizadorSeguroGUI extends JFrame {

    // Componentes de datos del vehículo
    private JTextField txtMarca;
    private JTextField txtModelo;
    private JSpinner spnAnio;
    private JTextField txtValorVehiculo;

    // Componentes de datos del conductor
    private JTextField txtNombreConductor;
    private JSpinner spnEdad;
    private JComboBox<String> cmbGenero;
    private JSpinner spnExperiencia;

    // Componentes de opciones del seguro
    private JComboBox<String> cmbTipoCobertura;
    private JCheckBox chkAsistenciaVial;
    private JCheckBox chkVehiculoReemplazo;
    private JComboBox<String> cmbDeducible;

    // Componentes de resultados
    private JTextArea txtResultados;
    private JButton btnCotizar;
    private JButton btnLimpiar;
    private JButton btnGenerarReporte;

    // Formato para números
    private DecimalFormat formatoMoneda;

    /**
     * Constructor que inicializa la interfaz gráfica.
     */
    public CotizadorSeguroGUI() {
        formatoMoneda = new DecimalFormat("$#,##0.00");
        inicializarComponentes();
        configurarVentana();
    }

    /**
     * Configura las propiedades básicas de la ventana.
     */
    private void configurarVentana() {
        setTitle("Sistema de Cotización de Seguros de Automóviles");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Panel principal con padding
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout(10, 10));
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        panelPrincipal.setBackground(new Color(240, 248, 255));

        // Agregar paneles
        JPanel panelSuperior = crearPanelSuperior();
        JPanel panelCentral = crearPanelCentral();
        JPanel panelInferior = crearPanelInferior();

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
        panelPrincipal.add(new JScrollPane(panelCentral), BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);

        // Configurar tamaño y posición
        setMinimumSize(new Dimension(900, 750));
        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Inicializa todos los componentes de la interfaz.
     */
    private void inicializarComponentes() {
        // Datos del vehículo
        txtMarca = new JTextField(20);
        txtModelo = new JTextField(20);

        int anioActual = Calendar.getInstance().get(Calendar.YEAR);
        SpinnerModel modeloAnio = new SpinnerNumberModel(anioActual, 1990, anioActual + 1, 1);
        spnAnio = new JSpinner(modeloAnio);

        txtValorVehiculo = new JTextField(15);

        // Datos del conductor
        txtNombreConductor = new JTextField(30);

        SpinnerModel modeloEdad = new SpinnerNumberModel(30, 18, 100, 1);
        spnEdad = new JSpinner(modeloEdad);

        cmbGenero = new JComboBox<>(new String[]{"Masculino", "Femenino"});

        SpinnerModel modeloExperiencia = new SpinnerNumberModel(5, 0, 50, 1);
        spnExperiencia = new JSpinner(modeloExperiencia);

        // Opciones del seguro
        cmbTipoCobertura = new JComboBox<>(new String[]{"Básica", "Intermedia", "Premium"});
        chkAsistenciaVial = new JCheckBox("Incluir Asistencia Vial (+$500/año)");
        chkVehiculoReemplazo = new JCheckBox("Incluir Vehículo de Reemplazo (+$1,200/año)");
        cmbDeducible = new JComboBox<>(new String[]{"0%", "5%", "10%", "15%", "20%"});

        // Área de resultados
        txtResultados = new JTextArea(12, 60);
        txtResultados.setEditable(false);
        txtResultados.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtResultados.setBackground(new Color(250, 250, 250));

        // Botones
        btnCotizar = new JButton("Calcular Cotización");
        btnCotizar.setBackground(new Color(0, 123, 255));
        btnCotizar.setForeground(Color.WHITE);
        btnCotizar.setFont(new Font("Arial", Font.BOLD, 14));
        btnCotizar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnLimpiar = new JButton("Limpiar Formulario");
        btnLimpiar.setBackground(new Color(108, 117, 125));
        btnLimpiar.setForeground(Color.WHITE);
        btnLimpiar.setFont(new Font("Arial", Font.BOLD, 14));
        btnLimpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnGenerarReporte = new JButton("Generar Reporte PDF");
        btnGenerarReporte.setBackground(new Color(40, 167, 69));
        btnGenerarReporte.setForeground(Color.WHITE);
        btnGenerarReporte.setFont(new Font("Arial", Font.BOLD, 14));
        btnGenerarReporte.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnGenerarReporte.setEnabled(false);

        // Configurar eventos
        configurarEventos();
    }

    /**
     * Crea el panel superior con el título y descripción.
     */
    private JPanel crearPanelSuperior() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(33, 37, 41));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Sistema de Cotización de Seguros");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setHorizontalAlignment(JLabel.CENTER);

        JLabel lblSubtitulo = new JLabel("Ingrese los datos para calcular la prima del seguro");
        lblSubtitulo.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSubtitulo.setForeground(new Color(200, 200, 200));
        lblSubtitulo.setHorizontalAlignment(JLabel.CENTER);

        panel.add(lblTitulo, BorderLayout.NORTH);
        panel.add(lblSubtitulo, BorderLayout.CENTER);

        return panel;
    }

    /**
     * Crea el panel central con todos los formularios de entrada.
     */
    private JPanel crearPanelCentral() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Panel de datos del vehículo
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(crearPanelVehiculo(), gbc);

        // Panel de datos del conductor
        gbc.gridy = 1;
        panel.add(crearPanelConductor(), gbc);

        // Panel de opciones del seguro
        gbc.gridy = 2;
        panel.add(crearPanelOpciones(), gbc);

        // Panel de botones
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(crearPanelBotones(), gbc);

        // Panel de resultados
        gbc.gridy = 4;
        panel.add(crearPanelResultados(), gbc);

        return panel;
    }

    /**
     * Crea el panel con los datos del vehículo.
     */
    private JPanel crearPanelVehiculo() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(0, 123, 255), 2),
            "Datos del Vehículo",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 14),
            new Color(0, 123, 255)
        ));
        panel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Marca
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Marca:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(txtMarca, gbc);

        // Modelo
        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Modelo:"), gbc);
        gbc.gridx = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(txtModelo, gbc);

        // Año
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Año:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(spnAnio, gbc);

        // Valor
        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Valor del Vehículo ($):"), gbc);
        gbc.gridx = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(txtValorVehiculo, gbc);

        return panel;
    }

    /**
     * Crea el panel con los datos del conductor.
     */
    private JPanel crearPanelConductor() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(40, 167, 69), 2),
            "Datos del Conductor",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 14),
            new Color(40, 167, 69)
        ));
        panel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Nombre
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nombre Completo:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(txtNombreConductor, gbc);

        // Edad
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Edad:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(spnEdad, gbc);

        // Género
        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Género:"), gbc);
        gbc.gridx = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(cmbGenero, gbc);

        // Años de experiencia
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Años de Experiencia:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(spnExperiencia, gbc);

        return panel;
    }

    /**
     * Crea el panel con las opciones del seguro.
     */
    private JPanel crearPanelOpciones() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(255, 193, 7), 2),
            "Opciones del Seguro",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 14),
            new Color(255, 193, 7)
        ));
        panel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Tipo de cobertura
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Tipo de Cobertura:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(cmbTipoCobertura, gbc);

        // Deducible
        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel("Deducible:"), gbc);
        gbc.gridx = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(cmbDeducible, gbc);

        // Servicios adicionales
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(chkAsistenciaVial, gbc);

        gbc.gridx = 2;
        gbc.gridwidth = 2;
        panel.add(chkVehiculoReemplazo, gbc);

        return panel;
    }

    /**
     * Crea el panel con los botones de acción.
     */
    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setBackground(new Color(240, 248, 255));

        btnCotizar.setPreferredSize(new Dimension(180, 40));
        btnLimpiar.setPreferredSize(new Dimension(180, 40));
        btnGenerarReporte.setPreferredSize(new Dimension(180, 40));

        panel.add(btnCotizar);
        panel.add(btnLimpiar);
        panel.add(btnGenerarReporte);

        return panel;
    }

    /**
     * Crea el panel de resultados.
     */
    private JPanel crearPanelResultados() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(52, 58, 64), 2),
            "Resultados de la Cotización",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 14),
            new Color(52, 58, 64)
        ));
        panel.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(txtResultados);
        scrollPane.setPreferredSize(new Dimension(800, 200));
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    /**
     * Crea el panel inferior con información adicional.
     */
    private JPanel crearPanelInferior() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(52, 58, 64));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblInfo = new JLabel("Sistema de Cotización v1.0 - Todos los derechos reservados");
        lblInfo.setForeground(Color.WHITE);
        lblInfo.setHorizontalAlignment(JLabel.CENTER);

        panel.add(lblInfo, BorderLayout.CENTER);

        return panel;
    }

    /**
     * Configura los eventos de los componentes.
     */
    private void configurarEventos() {
        btnCotizar.addActionListener(e -> realizarCotizacion());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnGenerarReporte.addActionListener(e -> generarReporte());

        // Validación de entrada numérica en el valor del vehículo
        txtValorVehiculo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) && c != '.' && c != java.awt.event.KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
    }

    /**
     * Realiza la cotización del seguro.
     */
    private void realizarCotizacion() {
        try {
            // Validar datos de entrada
            if (!validarDatosEntrada()) {
                return;
            }

            // Obtener datos del formulario
            String marca = txtMarca.getText().trim();
            String modelo = txtModelo.getText().trim();
            int anio = (Integer) spnAnio.getValue();
            double valor = Double.parseDouble(txtValorVehiculo.getText().trim());
            String nombre = txtNombreConductor.getText().trim();
            int edad = (Integer) spnEdad.getValue();
            String genero = (String) cmbGenero.getSelectedItem();
            int experiencia = (Integer) spnExperiencia.getValue();
            String cobertura = (String) cmbTipoCobertura.getSelectedItem();
            boolean asistencia = chkAsistenciaVial.isSelected();
            boolean reemplazo = chkVehiculoReemplazo.isSelected();
            String deducibleStr = (String) cmbDeducible.getSelectedItem();
            int deducible = Integer.parseInt(deducibleStr.replace("%", ""));

            // Crear objeto cotizador
            CotizadorSeguro cotizador = new CotizadorSeguro(
                marca, modelo, anio, valor, nombre, edad, genero,
                experiencia, cobertura, asistencia, reemplazo, deducible
            );

            // Verificar elegibilidad
            if (!cotizador.esElegible()) {
                JOptionPane.showMessageDialog(this,
                    "Lo sentimos, el conductor no es elegible para el seguro.\n" +
                    "Verifique la edad y otros requisitos.",
                    "No Elegible",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Calcular cotización
            double primaTotal = cotizador.calcularPrimaTotal();
            double primaMensual = cotizador.calcularPrimaMensual();
            String resumen = cotizador.generarResumenCotizacion();

            // Mostrar resultados
            StringBuilder resultado = new StringBuilder();
            resultado.append("====================================================\n");
            resultado.append("          COTIZACIÓN DE SEGURO DE AUTOMÓVIL         \n");
            resultado.append("====================================================\n\n");

            resultado.append("DATOS DEL VEHÍCULO:\n");
            resultado.append("-------------------\n");
            resultado.append("Marca: ").append(marca).append("\n");
            resultado.append("Modelo: ").append(modelo).append("\n");
            resultado.append("Año: ").append(anio).append("\n");
            resultado.append("Valor: ").append(formatoMoneda.format(valor)).append("\n\n");

            resultado.append("DATOS DEL CONDUCTOR:\n");
            resultado.append("--------------------\n");
            resultado.append("Nombre: ").append(nombre).append("\n");
            resultado.append("Edad: ").append(edad).append(" años\n");
            resultado.append("Género: ").append(genero).append("\n");
            resultado.append("Experiencia: ").append(experiencia).append(" años\n\n");

            resultado.append("OPCIONES SELECCIONADAS:\n");
            resultado.append("----------------------\n");
            resultado.append("Tipo de Cobertura: ").append(cobertura).append("\n");
            resultado.append("Deducible: ").append(deducible).append("%\n");
            resultado.append("Asistencia Vial: ").append(asistencia ? "Sí" : "No").append("\n");
            resultado.append("Vehículo de Reemplazo: ").append(reemplazo ? "Sí" : "No").append("\n\n");

            resultado.append("====================================================\n");
            resultado.append("RESULTADO DE LA COTIZACIÓN:\n");
            resultado.append("====================================================\n");
            resultado.append("Prima Anual: ").append(formatoMoneda.format(primaTotal)).append("\n");
            resultado.append("Prima Mensual: ").append(formatoMoneda.format(primaMensual)).append("\n\n");

            if (cotizador.calificaDescuentoBuenConductor()) {
                resultado.append("¡Felicitaciones! Califica para descuento de buen conductor.\n");
            }

            if (cotizador.requiereInspeccion()) {
                resultado.append("Nota: Este vehículo requiere inspección previa.\n");
            }

            resultado.append("\n").append(resumen);

            txtResultados.setText(resultado.toString());
            btnGenerarReporte.setEnabled(true);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Por favor, ingrese un valor numérico válido para el vehículo.",
                "Error en Datos",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Ocurrió un error al realizar la cotización: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Valida los datos de entrada del formulario.
     */
    private boolean validarDatosEntrada() {
        if (txtMarca.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese la marca del vehículo.",
                "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
            txtMarca.requestFocus();
            return false;
        }

        if (txtModelo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el modelo del vehículo.",
                "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
            txtModelo.requestFocus();
            return false;
        }

        if (txtValorVehiculo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el valor del vehículo.",
                "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
            txtValorVehiculo.requestFocus();
            return false;
        }

        try {
            double valor = Double.parseDouble(txtValorVehiculo.getText().trim());
            if (valor <= 0) {
                JOptionPane.showMessageDialog(this, "El valor del vehículo debe ser mayor a 0.",
                    "Valor Inválido", JOptionPane.WARNING_MESSAGE);
                txtValorVehiculo.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un valor numérico válido.",
                "Formato Inválido", JOptionPane.WARNING_MESSAGE);
            txtValorVehiculo.requestFocus();
            return false;
        }

        if (txtNombreConductor.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el nombre del conductor.",
                "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
            txtNombreConductor.requestFocus();
            return false;
        }

        return true;
    }

    /**
     * Limpia todos los campos del formulario.
     */
    private void limpiarFormulario() {
        txtMarca.setText("");
        txtModelo.setText("");
        spnAnio.setValue(Calendar.getInstance().get(Calendar.YEAR));
        txtValorVehiculo.setText("");
        txtNombreConductor.setText("");
        spnEdad.setValue(30);
        cmbGenero.setSelectedIndex(0);
        spnExperiencia.setValue(5);
        cmbTipoCobertura.setSelectedIndex(0);
        chkAsistenciaVial.setSelected(false);
        chkVehiculoReemplazo.setSelected(false);
        cmbDeducible.setSelectedIndex(0);
        txtResultados.setText("");
        btnGenerarReporte.setEnabled(false);
        txtMarca.requestFocus();
    }

    /**
     * Genera un reporte PDF de la cotización (simulado).
     */
    private void generarReporte() {
        JOptionPane.showMessageDialog(this,
            "El reporte PDF ha sido generado exitosamente.\n" +
            "Archivo: Cotizacion_" + System.currentTimeMillis() + ".pdf",
            "Reporte Generado",
            JOptionPane.INFORMATION_MESSAGE);
    }
}