[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/L9J_2zze)
# 🚗 Sistema de Cotización de Seguros de Automóviles

## Descripción del Proyecto

Este ejercicio práctico te enseñará a implementar un sistema de cotización de seguros de automóviles en Java. Deberás completar la lógica de negocio que calcula las primas de seguro basándose en múltiples factores como el valor del vehículo, la edad del conductor, años de experiencia y tipo de cobertura.

## Objetivos de Aprendizaje

Al completar este ejercicio, aprenderás:

- ✅ Implementar lógica de negocio compleja con múltiples factores
- ✅ Trabajar con cálculos matemáticos y reglas de negocio
- ✅ Manejar diferentes tipos de datos y validaciones
- ✅ Aplicar descuentos y recargos según condiciones específicas
- ✅ Integrar componentes de lógica con una interfaz gráfica
- ✅ Escribir código limpio y bien documentado

## Instrucciones de Configuración

### 1. Clonar el Repositorio
```bash
git clone [URL_DEL_REPOSITORIO]
cd cotizador-seguro
```

### 2. Verificar Requisitos
- **Java 21** o superior instalado
- **Maven 3.6** o superior instalado
- IDE recomendado: IntelliJ IDEA, Eclipse o NetBeans

### 3. Importar el Proyecto
1. Abre tu IDE favorito
2. Importa el proyecto como proyecto Maven
3. Espera a que Maven descargue las dependencias

### 4. Estructura del Proyecto
```
cotizador-seguro/
├── src/
│   ├── main/
│   │   └── java/
│   │       └── edu/eam/ingesoft/logica/cotizador/
│   │           ├── CotizadorSeguro.java      # ⚠️ IMPLEMENTAR
│   │           ├── CotizadorSeguroGUI.java   # ✅ Completo
│   │           └── Main.java                 # ✅ Completo
│   └── test/
│       └── java/
│           └── edu/eam/ingesoft/logica/cotizador/
│               └── CotizadorSeguroTest.java  # ✅ Tests listos
├── pom.xml
├── README.md
└── .github/
    └── workflows/
        └── classroom.yml
```

## 📋 Pasos para Completar el Ejercicio

### Fase 1: Análisis y Comprensión
1. **Estudiar la clase `CotizadorSeguro.java`** - Revisar todos los atributos, constructor y métodos TODO
2. **Analizar los tests unitarios** - Entender qué comportamiento se espera de cada método
3. **Revisar las reglas de negocio** - Comprender todas las tablas y fórmulas explicadas abajo
4. **Identificar las dependencias** - Ver qué métodos dependen de otros para determinar el orden de implementación

### Fase 2: Implementación Básica
5. **Implementar `calcularPrimaBase()`** - Aplicar porcentajes según tipo de cobertura
6. **Implementar `calcularFactorEdad()`** - Retornar multiplicador según edad del conductor
7. **Implementar `calcularFactorExperiencia()`** - Retornar factor según años de experiencia
8. **Implementar `calcularFactorAntiguedad()`** - Calcular factor basado en antigüedad del vehículo

### Fase 3: Descuentos y Costos Adicionales
9. **Implementar `calcularDescuentoDeducible()`** - Retornar descuento decimal (0.0 a 0.15)
10. **Implementar `calcularCostosAdicionales()`** - Sumar costos de servicios extras seleccionados

### Fase 4: Cálculos Principales
11. **Implementar `calcularPrimaTotal()`** - Aplicar la fórmula principal combinando todos los factores
12. **Implementar `calcularPrimaMensual()`** - Dividir prima anual entre 12

### Fase 5: Validaciones y Condiciones
13. **Implementar `esElegible()`** - Verificar criterios mínimos de elegibilidad
14. **Implementar `calificaDescuentoBuenConductor()`** - Evaluar condiciones para descuento especial
15. **Implementar `validarDatos()`** - Validar consistencia de todos los datos ingresados

### Fase 6: Funcionalidades Especiales
16. **Implementar `calcularMontoMaximoCobertura()`** - Calcular cobertura máxima según tipo
17. **Implementar `requiereInspeccion()`** - Determinar si necesita inspección previa
18. **Implementar `generarResumenCotizacion()`** - Crear string formateado con todos los datos

### Fase 7: Pruebas y Verificación
19. **Ejecutar tests después de cada método** - Verificar que la implementación sea correcta
20. **Corregir errores encontrados** - Ajustar la lógica según los resultados de los tests
21. **Ejecutar todos los tests juntos** - Asegurar que todo funcione en conjunto
22. **Probar la interfaz gráfica** - Verificar que los cálculos se muestren correctamente

### Notas Importantes:
- **Orden sugerido**: Sigue el orden listado ya que algunos métodos dependen de otros
- **Pruebas incrementales**: No implementes todo de una vez, prueba método por método
- **Atención a los detalles**: Los tests son muy específicos con valores esperados
- **Valores decimales**: Los descuentos deben retornarse como decimales (0.15 no 15)

## 📊 Reglas de Negocio

### 1. Prima Base
La prima base se calcula como un porcentaje del valor del vehículo:

| Tipo de Cobertura | Porcentaje del Valor |
|-------------------|---------------------|
| Básica           | 3% del valor        |
| Intermedia       | 4% del valor        |
| Premium          | 5% del valor        |

### 2. Factor de Edad del Conductor

| Edad del Conductor | Factor Multiplicador |
|-------------------|---------------------|
| Menos de 25 años  | 1.5                |
| 25 a 65 años      | 1.0                |
| Más de 65 años    | 1.3                |

### 3. Factor de Experiencia

| Años de Experiencia | Factor Multiplicador |
|--------------------|---------------------|
| Menos de 2 años    | 1.3                |
| 2 a 5 años         | 1.1                |
| 5 a 10 años        | 1.0                |
| Más de 10 años     | 0.9                |

### 4. Factor de Antigüedad del Vehículo

| Antigüedad del Vehículo | Factor Multiplicador |
|------------------------|---------------------|
| 0 a 3 años             | 1.0                |
| 4 a 7 años             | 1.1                |
| 8 a 10 años            | 1.2                |
| Más de 10 años         | 1.3                |

### 5. Descuento por Deducible

| Deducible | Descuento |
|-----------|-----------|
| 0%        | 0%        |
| 5%        | 3%        |
| 10%       | 7%        |
| 15%       | 11%       |
| 20%       | 15%       |

### 6. Costos Adicionales
- **Asistencia Vial**: $500 anuales
- **Vehículo de Reemplazo**: $1,200 anuales

### 7. Fórmula de Prima Total
```
Prima Total = (Prima Base × Factor Edad × Factor Experiencia × Factor Antigüedad)
              × (1 - Descuento Deducible) + Costos Adicionales
```

### 8. Condiciones Especiales

#### Elegibilidad
- El conductor debe tener **mínimo 18 años**
- El vehículo debe tener un valor mayor a $0

#### Descuento Buen Conductor
Aplica si se cumplen TODAS las condiciones:
- Edad entre 30 y 60 años
- Más de 5 años de experiencia
- Sin siniestros previos (asumido)

#### Requiere Inspección
- Vehículos con más de 10 años de antigüedad
- Vehículos con valor superior a $50,000

#### Monto Máximo de Cobertura
| Tipo de Cobertura | Monto Máximo           |
|-------------------|------------------------|
| Básica           | Valor del vehículo     |
| Intermedia       | Valor × 1.5            |
| Premium          | Valor × 2              |

## 🧪 Ejecutar Tests

### Localmente
```bash
# Ejecutar todos los tests
mvn test

# Ejecutar un test específico
mvn test -Dtest=CotizadorSeguroTest#testCalcularPrimaBase
```

### Ver Resultados
Los resultados aparecerán en la consola mostrando:
- ✅ Tests aprobados en verde
- ❌ Tests fallidos en rojo
- Detalles de los errores y valores esperados vs obtenidos

## 🎮 Probar la Interfaz Gráfica

1. **Compilar el proyecto:**
```bash
mvn clean compile
```

2. **Ejecutar la aplicación:**
```bash
mvn exec:java -Dexec.mainClass="edu.eam.ingesoft.logica.cotizador.Main"
```

3. **Usar la interfaz:**
   - Ingresa los datos del vehículo (marca, modelo, año, valor)
   - Completa la información del conductor
   - Selecciona las opciones de seguro deseadas
   - Click en "Calcular Cotización"
   - Los resultados aparecerán en el panel inferior

## 📊 Criterios de Evaluación

| Componente | Puntos | Descripción |
|------------|--------|-------------|
| Prima Base | 12 | Cálculo correcto según tipo de cobertura |
| Factores de Ajuste | 20 | Edad, experiencia y antigüedad |
| Descuentos | 8 | Aplicación correcta de descuentos |
| Costos Adicionales | 8 | Suma de servicios extras |
| Prima Total | 12 | Integración de todos los componentes |
| Validaciones | 16 | Elegibilidad y validación de datos |
| Condiciones Especiales | 16 | Buen conductor, inspección, etc. |
| Métodos Auxiliares | 8 | Getters, setters y resumen |
| **TOTAL** | **100** | |

## 💡 Consejos y Ayuda

### Estrategia Recomendada
1. **Empieza simple**: Implementa primero los métodos más básicos
2. **Prueba incrementalmente**: Ejecuta tests después de cada método
3. **Lee los tests**: Los tests te dan pistas sobre los valores esperados
4. **Usa el depurador**: Si un test falla, depura paso a paso

### Errores Comunes
- **División entre cero**: Verifica denominadores antes de dividir
- **Null Pointer**: Valida que los strings no sean null
- **Tipos incorrectos**: Usa los tipos de datos apropiados
- **Redondeo**: Ten cuidado con el redondeo de decimales

### Ejemplo de Implementación (Prima Base)
```java
public double calcularPrimaBase() {
    double porcentaje = 0;

    if (tipoCobertura.equals("Básica")) {
        porcentaje = 0.03;  // 3%
    } else if (tipoCobertura.equals("Intermedia")) {
        porcentaje = 0.04;  // 4%
    } else if (tipoCobertura.equals("Premium")) {
        porcentaje = 0.05;  // 5%
    }

    return valorVehiculo * porcentaje;
}
```

## 📚 Recursos Adicionales

- [Documentación de Java](https://docs.oracle.com/en/java/)
- [JUnit 5 User Guide](https://junit.org/junit5/docs/current/user-guide/)
- [Maven Getting Started](https://maven.apache.org/guides/getting-started/)

## 🆘 ¿Necesitas Ayuda?

Si tienes problemas:
1. Revisa los mensajes de error en los tests
2. Verifica que estés usando Java 21
3. Asegúrate de que Maven esté instalado correctamente
4. Consulta con tu instructor o compañeros
5. Revisa los ejemplos en este README

## 🎯 Entrega

1. Implementa todos los métodos requeridos
2. Asegúrate de que todos los tests pasen
3. Haz commit y push de tus cambios
4. GitHub Classroom evaluará automáticamente tu trabajo

---

**¡Buena suerte con tu implementación!** 🚀

Recuerda: El objetivo es aprender, no solo pasar los tests. Tómate tu tiempo para entender cada parte del código.# template_decisiones_multiples
